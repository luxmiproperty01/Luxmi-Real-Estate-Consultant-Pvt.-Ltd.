LUXMI PROPERTY WEBSITE

Files:
- index.html — complete responsive website.

To publish for free:
1. Open index.html in a browser to preview it.
2. Upload it to a static hosting service such as GitHub Pages, Cloudflare Pages, or Netlify.
3. Replace the placeholder property photos with your own photos when ready.

Before publishing, verify phone numbers, address, Instagram ID, property details, and WhatsApp number.
